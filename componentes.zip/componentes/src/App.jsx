import { Uno } from './Components/uno';
import { Dos } from './Components/dos';

import './App.css'

function App() {
  return (
    <div className='container'>
      
      <div>
        <Uno nombre="Daniel Paolo" edad={53} RH="O-" numeroDeTelefono="3202021908" nacionalidad="Venezolano" />
        <Uno nombre="Paquito Anselmo" RH="O+" edad={89} numeroDeTelefono="123456" nacionalidad="Colombiano" />
        <Uno nombre="Guillermo Leonardo" RH="AB-" edad={50} numeroDeTelefono="654321" nacionalidad="Argentino" />
        <Uno nombre="Marco Andrés" RH="A-" edad={23} numeroDeTelefono="654321" nacionalidad="Ecuatoriano" />
      </div>

      <div>
        <Dos pais="Colombia" capital="Bogotá" poblacion="3.300" />
        <Dos pais="Venezuela" capital="Caracas" poblacion="1.000" />
        <Dos pais="Argentina" capital="Buenos Aires" poblacion="2.300" />
        <Dos pais="Salvador" capital="San Salvador" poblacion="4.220" />
      </div>

    </div>
  );
}

export default App;

