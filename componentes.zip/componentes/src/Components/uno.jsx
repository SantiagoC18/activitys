export const Uno = (props) => {
    return <div>
        <h1>{props.nombre}</h1>
        <p>{props.edad}</p>
        <p>{props.RH}</p>
        <p>{props.numeroDeTelefono}</p>
        <p>{props.nacionalidad}</p>
        <hr />
    </div>;
}