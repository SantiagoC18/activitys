export const Dos = (props) => {
    return <div>
        <h1>{props.pais}</h1>
        <p>{props.capital}</p>
        <p>{props.poblacion}</p>
        <hr />
    </div>;
}